import os
import subprocess

def convert_to_gguf(model_dir, output_dir="gguf_output"):
    os.makedirs(output_dir, exist_ok=True)
    cmd = f"python3 convert.py --outtype q4_0 --outfile {output_dir}/finetuned.gguf {model_dir}"
    subprocess.run(cmd, shell=True)