from bert_score import score as bert_score
from rouge import Rouge
from nltk.translate.bleu_score import sentence_bleu
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
import math

def evaluate(model_dir, tokenizer, test_sentences, reference_answers):
    model = AutoModelForCausalLM.from_pretrained(model_dir, device_map="auto")
    model.eval()

    rouge = Rouge()
    all_preds = []
    for sentence in test_sentences:
        inputs = tokenizer(sentence, return_tensors="pt").to("cuda")
        outputs = model.generate(**inputs, max_new_tokens=50)
        pred = tokenizer.decode(outputs[0], skip_special_tokens=True)
        all_preds.append(pred)

    P, R, F1 = bert_score(all_preds, reference_answers, lang="en", verbose=True)
    print("BERTScore:", F1.mean().item())

    scores = rouge.get_scores(all_preds, reference_answers, avg=True)
    print("ROUGE:", scores)

    bleu_scores = [sentence_bleu([ref.split()], pred.split()) for ref, pred in zip(reference_answers, all_preds)]
    print("BLEU (avg):", sum(bleu_scores)/len(bleu_scores))

    ppl = calculate_perplexity(model, tokenizer, reference_answers)
    print("Perplexity:", ppl)

def calculate_perplexity(model, tokenizer, texts):
    losses = []
    for text in texts:
        inputs = tokenizer(text, return_tensors="pt").to("cuda")
        with torch.no_grad():
            outputs = model(**inputs, labels=inputs["input_ids"])
            loss = outputs.loss
            losses.append(loss.item())
    return math.exp(sum(losses) / len(losses))