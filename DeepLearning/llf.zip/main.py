import argparse
from dataset_prep import prepare_dataset
from finetune import finetune
from convert_to_gguf import convert_to_gguf
from evaluation import evaluate

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--method", choices=["lora", "qlora", "full"], default="lora")
    parser.add_argument("--model_path", type=str, default="llama2")  # your Ollama local model
    parser.add_argument("--dataset", type=str, default="data/training_data.json")
    parser.add_argument("--log_wandb", action="store_true")
    parser.add_argument("--skip_eval", action="store_true")
    args = parser.parse_args()

    dataset, tokenizer = prepare_dataset(args.model_path, args.dataset)
    finetune(args.model_path, dataset, tokenizer, method=args.method, use_wandb=args.log_wandb)
    convert_to_gguf("finetuned_model")

    if not args.skip_eval:
        test_inputs = ["What is AI?", "Benefits of renewable energy?", "How to plant a tree?"]
        expected_outputs = ["Artificial Intelligence is the simulation of human intelligence...",
                            "Renewable energy is sustainable and reduces emissions...",
                            "To plant a tree, dig a hole, place the sapling..."]
        evaluate("finetuned_model", tokenizer, test_inputs, expected_outputs)

if __name__ == "__main__":
    main()