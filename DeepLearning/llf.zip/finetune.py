import torch
from transformers import AutoModelForCausalLM, TrainingArguments, Trainer, DataCollatorForLanguageModeling
from peft import get_peft_model, LoraConfig, TaskType, prepare_model_for_kbit_training
from transformers import BitsAndBytesConfig
import os

def finetune(model_path, tokenized_data, tokenizer, method="lora", log_dir="logs", use_wandb=False):
    if method.lower() == "qlora":
        quantization_config = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_use_double_quant=True,
                                                 bnb_4bit_quant_type="nf4", bnb_4bit_compute_dtype=torch.float16)
        model = AutoModelForCausalLM.from_pretrained(model_path, quantization_config=quantization_config, device_map="auto")
        model = prepare_model_for_kbit_training(model)
    else:
        model = AutoModelForCausalLM.from_pretrained(model_path, load_in_8bit=(method=="lora"), device_map="auto")

    if method in ["lora", "qlora"]:
        lora_config = LoraConfig(
            r=8, lora_alpha=16, target_modules=["q_proj", "v_proj"],
            lora_dropout=0.05, bias="none", task_type=TaskType.CAUSAL_LM
        )
        model = get_peft_model(model, lora_config)

    training_args = TrainingArguments(
        output_dir="./finetuned_model",
        per_device_train_batch_size=2,
        gradient_accumulation_steps=4,
        num_train_epochs=3,
        logging_steps=10,
        logging_dir=log_dir,
        save_strategy="epoch",
        fp16=True,
        report_to="wandb" if use_wandb else "tensorboard",
        run_name="LLM-finetuning"
    )

    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_data["train"],
        data_collator=DataCollatorForLanguageModeling(tokenizer=tokenizer, mlm=False)
    )

    trainer.train()
    model.save_pretrained("./finetuned_model")