from datasets import load_dataset
from transformers import AutoTokenizer

def prepare_dataset(model_path, file_path):
    tokenizer = AutoTokenizer.from_pretrained(model_path)

    dataset = load_dataset("json", data_files=file_path)

    def tokenize(example):
        return tokenizer(example["text"], truncation=True, padding="max_length", max_length=512)

    tokenized = dataset.map(tokenize)
    return tokenized, tokenizer